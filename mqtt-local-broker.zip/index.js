'use strict';
const { startServer } = require('./server');

startServer()
  .then((info) => {
    console.log(`MQTT-брокер: порт ${info.mqttPort}`);
    info.ips.forEach((i) => console.log(`  ${i.address}:${info.mqttPort}  (${i.name})`));
    console.log(`Веб-панель: http://localhost:${info.httpPort}`);
  })
  .catch((e) => {
    console.error(e.message);
    process.exit(1);
  });
