'use strict';
// Локальный MQTT-брокер + веб-панель с учётными записями.
//  - у каждого пользователя панели свои карточки, базовый топик и данные его ESP (хранятся в data/users.json);
//  - ESP подключается к брокеру с именем/паролем, сохранёнными в панели; её сообщения видны только владельцу,
//    а топики разных пользователей изолированы друг от друга (можно всем использовать /base/...).
//
//   const { startServer } = require('./server');
//   const info = await startServer({ mqttPort: 1883, httpPort: 8080, dataDir: '...' });
// В Node SEA папки public и data ищутся рядом с exe.

const net = require('net');
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const aedes = require('aedes');

const MAX_LOG = 300;

// Базовая папка: рядом с exe, если запущено как Node SEA, иначе папка проекта.
let isSea = false;
try { isSea = require('node:sea').isSea(); } catch (e) { /* старая версия Node или не SEA */ }
const baseDir = isSea ? path.dirname(process.execPath) : __dirname;

function getLocalIPs() {
  const res = [];
  const ifaces = os.networkInterfaces();
  for (const name of Object.keys(ifaces)) {
    for (const i of ifaces[name] || []) {
      if (i.family === 'IPv4' && !i.internal) res.push({ name, address: i.address });
    }
  }
  return res;
}

function listen(server, port, host) {
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, host, () => {
      server.removeListener('error', reject);
      resolve();
    });
  });
}

function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 32).toString('hex');
}

function safeEqual(a, b) {
  const x = Buffer.from(String(a));
  const y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

async function startServer(opts = {}) {
  const mqttPort = Number(opts.mqttPort || process.env.MQTT_PORT || 1883);
  const httpPort = Number(opts.httpPort || process.env.HTTP_PORT || 8080);
  const publicDir = opts.publicDir || path.join(baseDir, 'public');
  const dataDir = opts.dataDir || process.env.MQTT_DATA_DIR || path.join(baseDir, 'data');

  // ---------- хранилище пользователей ----------
  fs.mkdirSync(dataDir, { recursive: true });
  const dbFile = path.join(dataDir, 'users.json');
  let db = { users: {} };
  try {
    db = JSON.parse(fs.readFileSync(dbFile, 'utf8'));
    if (!db.users) db.users = {};
  } catch (e) {
    /* первый запуск */
  }

  function saveDb() {
    const tmp = dbFile + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
    fs.renameSync(tmp, dbFile);
  }

  const userKey = (name) => String(name).trim().toLowerCase();
  const userById = (id) => Object.values(db.users).find((u) => u.id === id);
  const prefixOf = (id) => `u/${id}/`;

  function findUserByEsp(name, pass) {
    if (!name) return null;
    return (
      Object.values(db.users).find(
        (u) => u.esp && u.esp.name && u.esp.name === name && safeEqual(u.esp.pass || '', pass)
      ) || null
    );
  }

  // ---------- состояние времени выполнения ----------
  const runtimes = new Map(); // userId -> { topics, log, esp, sse }
  function rt(id) {
    let r = runtimes.get(id);
    if (!r) {
      r = { topics: new Map(), log: [], esp: new Map(), sse: new Set() };
      runtimes.set(id, r);
    }
    return r;
  }

  function emit(id, type, data) {
    const line = `data: ${JSON.stringify({ type, data })}\n\n`;
    for (const res of rt(id).sse) res.write(line);
  }

  function addLog(id, entry) {
    const r = rt(id);
    r.log.push(entry);
    if (r.log.length > MAX_LOG) r.log.shift();
    emit(id, 'log', entry);
  }

  const espState = (id) => ({ online: rt(id).esp.size > 0, clients: [...rt(id).esp.values()] });

  // ---------- брокер ----------
  const broker = aedes();

  // Подключаются только ESP с именем/паролем, сохранёнными кем-то из пользователей.
  broker.authenticate = (client, username, password, cb) => {
    const user = findUserByEsp(username, password ? password.toString() : '');
    if (!user) {
      const err = new Error('Bad credentials');
      err.returnCode = 4;
      return cb(err, false);
    }
    client.userId = user.id;
    cb(null, true);
  };

  // Изоляция: внутри брокера топик пользователя хранится как "u/<id>/<топик>".
  broker.authorizePublish = (client, packet, cb) => {
    if (client && client.userId) packet.topic = prefixOf(client.userId) + packet.topic;
    cb(null);
  };
  broker.authorizeSubscribe = (client, sub, cb) => {
    const p = prefixOf(client.userId);
    if (!sub.topic.startsWith(p)) sub.topic = p + sub.topic;
    cb(null, sub);
  };
  broker.authorizeForward = (client, packet) => {
    const p = prefixOf(client.userId);
    if (!packet.topic.startsWith(p)) return null;
    return Object.assign({}, packet, { topic: packet.topic.slice(p.length) });
  };

  const splitTopic = (t) => {
    const m = /^u\/([0-9a-f]+)\/([\s\S]*)$/.exec(t);
    return m ? { id: m[1], topic: m[2] } : null;
  };

  broker.on('client', (c) => {
    if (!c.userId) return;
    const ip = c.conn && c.conn.remoteAddress ? c.conn.remoteAddress.replace('::ffff:', '') : '';
    rt(c.userId).esp.set(c.id, { id: c.id, ip, since: Date.now() });
    emit(c.userId, 'esp', espState(c.userId));
    addLog(c.userId, { ts: Date.now(), kind: 'sys', text: `ESP подключилась: ${c.id} (${ip})` });
  });

  broker.on('clientDisconnect', (c) => {
    if (!c.userId) return;
    rt(c.userId).esp.delete(c.id);
    emit(c.userId, 'esp', espState(c.userId));
    addLog(c.userId, { ts: Date.now(), kind: 'sys', text: `ESP отключилась: ${c.id}` });
  });

  broker.on('subscribe', (subs, c) => {
    if (!c.userId) return;
    const p = prefixOf(c.userId);
    addLog(c.userId, {
      ts: Date.now(),
      kind: 'sys',
      text: `${c.id} подписалась: ${subs.map((s) => (s.topic.startsWith(p) ? s.topic.slice(p.length) : s.topic)).join(', ')}`,
    });
  });

  broker.on('publish', (packet, client) => {
    const s = splitTopic(packet.topic);
    if (!s) return;
    const payload = packet.payload.toString();
    const from = client ? client.id : 'панель';
    const ts = Date.now();
    rt(s.id).topics.set(s.topic, { payload, ts, from });
    emit(s.id, 'topic', { topic: s.topic, payload, ts, from });
    addLog(s.id, { ts, kind: 'msg', topic: s.topic, payload, from, retain: !!packet.retain });
  });

  function publishAs(userId, topic, payload) {
    return new Promise((resolve, reject) => {
      broker.publish(
        { cmd: 'publish', qos: 0, dup: false, retain: false, topic: prefixOf(userId) + topic, payload: Buffer.from(String(payload)) },
        (err) => (err ? reject(err) : resolve())
      );
    });
  }

  function kickEsp(userId) {
    for (const c of Object.values(broker.clients)) if (c.userId === userId) c.close();
  }

  // ---------- MQTT по TCP (без шифрования) ----------
  const mqttServer = net.createServer(broker.handle);
  try {
    await listen(mqttServer, mqttPort, '0.0.0.0');
  } catch (e) {
    throw new Error(`Не удалось занять MQTT-порт ${mqttPort}: ${e.code || e.message}`);
  }

  // ---------- HTTP ----------
  const sessions = new Map(); // token -> userId
  const mime = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8' };

  const json = (res, code, obj) => {
    res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify(obj));
  };

  function readBody(req) {
    return new Promise((resolve, reject) => {
      let body = '';
      req.on('data', (d) => {
        body += d;
        if (body.length > 2e6) {
          reject(new Error('Слишком большой запрос'));
          req.destroy();
        }
      });
      req.on('end', () => {
        try {
          resolve(body ? JSON.parse(body) : {});
        } catch (e) {
          reject(new Error('Некорректный JSON'));
        }
      });
    });
  }

  function authUser(req, url) {
    const token = req.headers['x-token'] || url.searchParams.get('token');
    const id = token && sessions.get(token);
    return id ? userById(id) : null;
  }

  function newSession(user) {
    const token = crypto.randomBytes(24).toString('hex');
    sessions.set(token, user.id);
    return token;
  }

  async function handleApi(req, res, url) {
    const p = url.pathname;

    if (p === '/api/info' && req.method === 'GET') {
      return json(res, 200, { ips: getLocalIPs(), mqttPort, httpPort });
    }

    if (p === '/api/register' && req.method === 'POST') {
      const { name, password } = await readBody(req);
      const n = String(name || '').trim();
      if (n.length < 1 || n.length > 32) return json(res, 400, { error: 'Имя: от 1 до 32 символов' });
      if (String(password || '').length < 3) return json(res, 400, { error: 'Пароль: не короче 3 символов' });
      if (db.users[userKey(n)]) return json(res, 409, { error: 'Пользователь с таким именем уже есть' });
      const salt = crypto.randomBytes(16).toString('hex');
      const user = {
        id: crypto.randomBytes(4).toString('hex'),
        name: n,
        salt,
        hash: hashPassword(String(password), salt),
        base: '/base',
        cards: null, // null = ещё не настраивали, клиент создаст стандартный набор
        esp: { name: '', pass: '' },
      };
      db.users[userKey(n)] = user;
      saveDb();
      return json(res, 200, { token: newSession(user), name: user.name });
    }

    if (p === '/api/login' && req.method === 'POST') {
      const { name, password } = await readBody(req);
      const user = db.users[userKey(name || '')];
      if (!user || !safeEqual(user.hash, hashPassword(String(password || ''), user.salt))) {
        return json(res, 401, { error: 'Неверное имя или пароль' });
      }
      return json(res, 200, { token: newSession(user), name: user.name });
    }

    // дальше — только для вошедших
    const user = authUser(req, url);
    if (!user) return json(res, 401, { error: 'Требуется вход' });

    if (p === '/api/logout' && req.method === 'POST') {
      const token = req.headers['x-token'];
      sessions.delete(token);
      return json(res, 200, { ok: true });
    }

    if (p === '/api/events' && req.method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
      const r = rt(user.id);
      res.write(
        `data: ${JSON.stringify({
          type: 'init',
          data: { topics: Object.fromEntries(r.topics), log: r.log, esp: espState(user.id) },
        })}\n\n`
      );
      r.sse.add(res);
      req.on('close', () => r.sse.delete(res));
      return;
    }

    if (p === '/api/settings' && req.method === 'GET') {
      return json(res, 200, { name: user.name, base: user.base, cards: user.cards, esp: user.esp });
    }

    if (p === '/api/settings' && req.method === 'PUT') {
      const { base, cards } = await readBody(req);
      if (typeof base !== 'string' || !Array.isArray(cards) || cards.length > 400) {
        return json(res, 400, { error: 'Некорректные настройки' });
      }
      user.base = base;
      user.cards = cards;
      saveDb();
      return json(res, 200, { ok: true });
    }

    if (p === '/api/esp' && req.method === 'PUT') {
      const body = await readBody(req);
      const name = String(body.name || '').trim();
      const pass = String(body.pass || '');
      if (name) {
        const clash = Object.values(db.users).find((u) => u.id !== user.id && u.esp && u.esp.name === name);
        if (clash) return json(res, 409, { error: 'Это имя ESP уже используется другим пользователем' });
      }
      user.esp = { name, pass };
      saveDb();
      kickEsp(user.id); // пусть переподключится с новыми данными
      return json(res, 200, { ok: true });
    }

    if (p === '/api/publish' && req.method === 'POST') {
      const { topic, payload } = await readBody(req);
      if (!topic || typeof topic !== 'string') return json(res, 400, { error: 'Не указан топик' });
      await publishAs(user.id, topic, payload == null ? '' : payload);
      return json(res, 200, { ok: true });
    }

    return json(res, 404, { error: 'Not found' });
  }

  const httpServer = http.createServer((req, res) => {
    const url = new URL(req.url, 'http://localhost');

    if (url.pathname.startsWith('/api/')) {
      handleApi(req, res, url).catch((e) => {
        if (!res.headersSent) json(res, 400, { error: e.message });
      });
      return;
    }

    const file = url.pathname === '/' ? '/index.html' : decodeURIComponent(url.pathname);
    const full = path.normalize(path.join(publicDir, file));
    if (!full.startsWith(publicDir)) {
      res.writeHead(403);
      return res.end();
    }
    fs.readFile(full, (err, data) => {
      if (err) {
        res.writeHead(404);
        return res.end('Not found');
      }
      res.writeHead(200, { 'Content-Type': mime[path.extname(full)] || 'application/octet-stream' });
      res.end(data);
    });
  });

  try {
    await listen(httpServer, httpPort, '0.0.0.0');
  } catch (e) {
    mqttServer.close();
    throw new Error(`Не удалось занять HTTP-порт ${httpPort}: ${e.code || e.message}`);
  }

  async function stop() {
    for (const r of runtimes.values()) for (const s of r.sse) s.end();
    await new Promise((r) => httpServer.close(r));
    await new Promise((r) => mqttServer.close(r));
    await new Promise((r) => broker.close(r));
  }

  return { mqttPort, httpPort, ips: getLocalIPs(), dataDir, stop };
}

module.exports = { startServer, getLocalIPs };
