'use strict';
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const fmtTime = (ts) => new Date(ts).toLocaleTimeString();
const uid = () => Math.random().toString(36).slice(2, 9);

let token = sessionStorage.getItem('token'); // вход живёт до закрытия вкладки
let settings = null; // { base, cards, esp }
let topics = {};
let es = null;
let authMode = 'login';
let info = null;

const CARDS_PER_COLUMN = 8; // 2 x 4

/* ---------- запросы ---------- */
async function api(method, path, body) {
  const r = await fetch(path, {
    method,
    headers: { 'Content-Type': 'application/json', 'X-Token': token || '' },
    body: body ? JSON.stringify(body) : undefined,
  });
  let j = {};
  try { j = await r.json(); } catch (e) { /* пусто */ }
  if (r.status === 401 && token) toAuth();
  return { ok: r.ok, status: r.status, j };
}
const publish = (topic, payload) => api('POST', '/api/publish', { topic, payload });

/* ---------- адрес брокера ---------- */
async function loadInfo() {
  try { info = await (await fetch('/api/info')).json(); } catch (e) { return; }
  const list = info.ips.length ? info.ips : [{ address: '127.0.0.1', name: 'localhost' }];
  $('addr').innerHTML = list.map((i) =>
    `<div class="line"><span class="type">${esc(i.name)}</span>` +
    `<span class="ip" title="Нажмите, чтобы скопировать IP">${esc(i.address)}</span>` +
    `<span class="plabel">порт</span><span class="port">${info.mqttPort}</span></div>`).join('');
  $('addr').querySelectorAll('.ip').forEach((el) => (el.onclick = () => {
    if (navigator.clipboard) navigator.clipboard.writeText(el.textContent);
    else { const r = document.createRange(); r.selectNodeContents(el); const s = getSelection(); s.removeAllRanges(); s.addRange(r); document.execCommand('copy'); }
  }));
  $('hint').textContent = `В прошивке: mqtt_server = IP (без порта), mqtt_port = ${info.mqttPort}, mqtt_user и mqtt_password — имя и пароль ESP из блока «ESP».`;
}

/* ---------- вход / регистрация ---------- */
function setAuthMode(m) {
  authMode = m;
  $('tabLogin').classList.toggle('active', m === 'login');
  $('tabReg').classList.toggle('active', m === 'reg');
  $('aGo').textContent = m === 'login' ? 'Войти' : 'Зарегистрироваться';
  $('aPass').autocomplete = m === 'login' ? 'current-password' : 'new-password';
  $('aErr').textContent = '';
}
$('tabLogin').onclick = () => setAuthMode('login');
$('tabReg').onclick = () => setAuthMode('reg');
$('aGo').onclick = async () => {
  const r = await api('POST', authMode === 'login' ? '/api/login' : '/api/register', { name: $('aName').value, password: $('aPass').value });
  if (!r.ok) return ($('aErr').textContent = r.j.error || 'Ошибка');
  token = r.j.token;
  sessionStorage.setItem('token', token);
  startApp();
};
// addEventListener, а не onkeydown = ...: возвращённое false отменило бы ввод с клавиатуры
for (const id of ['aName', 'aPass']) {
  $(id).addEventListener('keydown', (e) => {
    if (e.key === 'Enter') $('aGo').click();
  });
}
$('logout').onclick = async () => { await api('POST', '/api/logout'); toAuth(); };

function toAuth() {
  if (es) { es.close(); es = null; }
  token = null;
  sessionStorage.removeItem('token');
  settings = null;
  $('app').hidden = true;
  $('userBox').hidden = true;
  $('modal').hidden = true;
  $('aPass').value = '';
  $('auth').hidden = false;
  setTimeout(() => $('aName').focus(), 0);
}

async function startApp() {
  const r = await api('GET', '/api/settings');
  if (!r.ok) return;
  settings = { base: r.j.base || '/base', cards: r.j.cards, esp: r.j.esp || { name: '', pass: '' } };
  if (!settings.cards) { settings.cards = defaultCards(bs()); await saveSettings(); }
  $('auth').hidden = true;
  $('app').hidden = false;
  $('userBox').hidden = false;
  $('userName').textContent = r.j.name;
  $('base').value = settings.base;
  $('espName').value = settings.esp.name;
  $('espPass').value = settings.esp.pass;
  $('espMsg').textContent = '';
  topics = {};
  renderDeck(); renderTopics();
  connect();
}

/* ---------- настройки ---------- */
const bs = () => (settings ? settings.base : '/base').replace(/\/+$/, '');
const saveSettings = () => api('PUT', '/api/settings', { base: settings.base, cards: settings.cards });
let baseTimer = null;
$('base').oninput = () => {
  settings.base = $('base').value;
  clearTimeout(baseTimer);
  baseTimer = setTimeout(saveSettings, 400);
};

/* ---------- ESP ---------- */
$('espShow').addEventListener('change', () => {
  $('espPass').type = $('espShow').checked ? 'text' : 'password';
});
$('espSave').onclick = async () => {
  const name = $('espName').value.trim();
  const pass = $('espPass').value;
  const r = await api('PUT', '/api/esp', { name, pass });
  $('espMsg').className = r.ok ? 'ok' : 'err';
  $('espMsg').textContent = r.ok ? 'Сохранено' : r.j.error || 'Ошибка';
  if (r.ok) settings.esp = { name, pass };
};
function renderEsp(s) {
  $('espDot').classList.toggle('on', s.online);
  $('espStatus').textContent = s.online
    ? 'ESP подключена: ' + s.clients.map((c) => `${c.id} (${c.ip})`).join(', ')
    : 'ESP не подключена';
}

/* ---------- карточки ---------- */
const PRESETS = [
  { label: 'Температура', make: (b) => ({ type: 'number', title: 'Температура', topic: b + '/temp', prefix: '', suffix: ' °C' }) },
  { label: 'Влажность', make: (b) => ({ type: 'number', title: 'Влажность', topic: b + '/humidity', prefix: '', suffix: ' %' }) },
  { label: 'Uptime', make: (b) => ({ type: 'number', title: 'Uptime', topic: b + '/uptime', prefix: '', suffix: ' с' }) },
  { label: 'Статус', make: (b) => ({ type: 'string', title: 'Статус', topic: b + '/status' }) },
  { label: 'Питание (переключатель)', make: (b) => ({ type: 'switch', title: 'Питание', topic: b + '/control', onValue: 'ON', offValue: 'OFF' }) },
];
const defaultCards = (b) => PRESETS.map((p) => ({ id: uid(), ...p.make(b) }));

const TYPE_NAMES = { string: 'Строка', number: 'Число', json: 'JSON', indicator: 'Индикатор', level: 'Уровень', switch: 'Переключатель', button: 'Кнопка' };

const val = (topic) => (topics[topic] ? topics[topic].payload : null);
const isNum = (v) => v != null && v.trim() !== '' && isFinite(Number(v.replace(',', '.')));
function pretty(v) {
  try {
    const o = JSON.parse(v);
    if (o !== null && typeof o === 'object') return JSON.stringify(o, null, 2);
  } catch (e) { /* не JSON */ }
  return null;
}

function cardHtml(c) {
  const v = val(c.topic);
  const del = `<button class="del" data-act="del" data-id="${c.id}" title="Удалить карточку">×</button>`;
  const head = `<div class="ct" title="${esc(c.topic)}">${esc(c.title)}</div>`;
  let body = '';
  switch (c.type) {
    case 'string':
      body = `<div class="strv">${v == null ? '—' : esc(v)}</div>`;
      break;
    case 'number':
      body = `<div class="big">${v == null ? '—' : isNum(v) ? esc(c.prefix) + esc(v) + esc(c.suffix) : esc(v)}</div>`;
      break;
    case 'json': {
      const p = v == null ? null : pretty(v);
      body = p ? `<pre>${esc(p)}</pre>` : `<div class="strv">${v == null ? '—' : esc(v)}</div>`;
      break;
    }
    case 'indicator': {
      const st = v === c.onValue ? 'on' : v === c.offValue ? 'off' : '';
      body = `<div class="led ${st}">${st === 'on' ? 'ВКЛ' : st === 'off' ? 'ВЫКЛ' : '—'}</div>`;
      break;
    }
    case 'level': {
      const min = Number(c.min), max = Number(c.max);
      const n = isNum(v) ? Number(v.replace(',', '.')) : null;
      const pct = n == null || max === min ? 0 : Math.max(0, Math.min(100, ((n - min) / (max - min)) * 100));
      body = `<div class="lvl"><div class="big" style="font-size:20px;margin-bottom:6px">${v == null ? '—' : n == null ? esc(v) : esc(c.prefix) + esc(v) + esc(c.suffix)}</div>` +
        `<div class="track"><div class="fill" style="width:${pct}%"></div></div>` +
        `<div class="lim"><span>${esc(c.min)}</span><span>${esc(c.max)}</span></div></div>`;
      break;
    }
    case 'switch': {
      const on = v === c.onValue;
      const txt = v === c.onValue ? 'ВКЛ' : v === c.offValue ? 'ВЫКЛ' : '—';
      body = `<div class="swrap"><button class="sw ${on ? 'on' : ''}" data-act="toggle" data-id="${c.id}"></button><b>${txt}</b></div>`;
      break;
    }
    case 'button':
      return `<div class="dcard btncard"><button class="cbtn" data-act="press" data-id="${c.id}">${esc(c.title)}</button>${del.replace('class="del"', 'class="del" style="color:#fff;z-index:2"')}</div>`;
  }
  return `<div class="dcard">${head}${del}<div class="body">${body}</div></div>`;
}

function renderDeck() {
  if (!settings) return;
  const deck = $('deck');
  const left = deck.scrollLeft;
  const cols = [];
  for (let i = 0; i < settings.cards.length; i += CARDS_PER_COLUMN) {
    cols.push(`<div class="col">${settings.cards.slice(i, i + CARDS_PER_COLUMN).map(cardHtml).join('')}</div>`);
  }
  deck.innerHTML = cols.join('') || '<div class="muted">Карточек нет. Нажмите «+», чтобы добавить.</div>';
  deck.scrollLeft = left;
}

$('deck').onclick = (e) => {
  const b = e.target.closest('[data-act]');
  if (!b) return;
  const c = settings.cards.find((x) => x.id === b.dataset.id);
  if (!c) return;
  if (b.dataset.act === 'del') {
    askConfirm(`Удалить карточку «${c.title}»?`, () => {
      settings.cards = settings.cards.filter((x) => x.id !== c.id);
      saveSettings(); renderDeck();
    });
  } else if (b.dataset.act === 'toggle') {
    publish(c.topic, val(c.topic) === c.onValue ? c.offValue : c.onValue);
  } else if (b.dataset.act === 'press') {
    publish(c.topic, c.value);
  }
};

function addCard(card) {
  settings.cards.push({ id: uid(), ...card });
  saveSettings(); renderDeck();
  const deck = $('deck');
  deck.scrollLeft = deck.scrollWidth;
}

/* ---------- окно добавления ---------- */
const openModal = () => ($('modal').hidden = false);
const closeModal = () => ($('modal').hidden = true);
$('mClose').onclick = closeModal;
$('modal').addEventListener('mousedown', (e) => {
  if (e.target === $('modal')) closeModal();
});
$('addBtn').onclick = () => { showPicker(); openModal(); };

// Своё окно подтверждения: системный confirm() в Electron ломает фокус полей ввода
function askConfirm(text, onYes) {
  $('mTitle').textContent = 'Подтверждение';
  $('mBody').innerHTML = `<div>${esc(text)}</div><div class="row" style="margin-top:14px"><button class="primary" id="cYes">Удалить</button><button id="cNo">Отмена</button></div>`;
  $('cYes').onclick = () => { closeModal(); onYes(); };
  $('cNo').onclick = closeModal;
  openModal();
}

function showPicker() {
  $('mTitle').textContent = 'Добавить карточку';
  $('mBody').innerHTML = '<div class="pick">' +
  '<div class="sep">Пустая</div><button data-p="blank">Выбрать тип карточки</button>' +
    '<div class="sep">Готовые</div>' +
    PRESETS.map((p, i) => `<button data-p="${i}">${esc(p.label)}</button>`).join('') +
    '</div>';
  $('mBody').querySelectorAll('[data-p]').forEach((b) => (b.onclick = () => {
    if (b.dataset.p === 'blank') return showBlank();
    addCard(PRESETS[Number(b.dataset.p)].make(bs()));
    closeModal();
  }));
}

function showBlank(type = 'string', keep = {}) {
  $('mTitle').textContent = 'Новая карточка';
  const f = (id, label, v = '', extra = '') => `<label>${label}</label><input type="text" id="${id}" value="${esc(v)}" ${extra}>`;
  let fields = f('fTitle', type === 'button' ? 'Текст на кнопке' : 'Название', keep.title || '') + f('fTopic', 'Топик', keep.topic != null ? keep.topic : bs() + '/');
  if (type === 'number') fields += f('fPrefix', 'Префикс') + f('fSuffix', 'Суффикс');
  if (type === 'indicator' || type === 'switch') fields += f('fOn', 'Значение ВКЛ', 'ON') + f('fOff', 'Значение ВЫКЛ', 'OFF');
  if (type === 'level') fields += f('fMin', 'Минимум', '0') + f('fMax', 'Максимум', '100') + f('fPrefix', 'Префикс') + f('fSuffix', 'Суффикс');
  if (type === 'button') fields += f('fVal', 'Значение, которое отправляется при нажатии');
  const group = (label, types) => `<optgroup label="${label}">${types.map((t) => `<option value="${t}" ${t === type ? 'selected' : ''}>${TYPE_NAMES[t]}</option>`).join('')}</optgroup>`;
  $('mBody').innerHTML =
    '<label>Тип данных</label><select id="fType">' + group('Индикация', ['string', 'number', 'json', 'indicator', 'level']) + group('Команды', ['switch', 'button']) + '</select>' +
    fields +
    '<div class="muted small">Пробелы в префиксе и суффиксе сохраняются.</div><div class="err" id="fErr"></div>' +
    '<div class="row" style="margin-top:10px"><button class="primary" id="fAdd">Добавить</button><button id="fBack">Назад</button></div>';
  $('fType').onchange = () => showBlank($('fType').value, { title: $('fTitle').value, topic: $('fTopic').value });
  $('fBack').onclick = showPicker;
  $('fAdd').onclick = () => {
    const g = (id) => ($(id) ? $(id).value : '');
    const t = $('fType').value;
    const topic = g('fTopic').trim();
    let title = g('fTitle').trim();
    const err = (m) => ($('fErr').textContent = m);
    if (!topic) return err('Укажите топик');
    if (!title) { if (t === 'button') return err('Укажите текст на кнопке'); title = TYPE_NAMES[t]; }
    const card = { type: t, title, topic };
    if (t === 'number') { card.prefix = g('fPrefix'); card.suffix = g('fSuffix'); }
    if (t === 'indicator' || t === 'switch') {
      if (g('fOn') === '' || g('fOff') === '') return err('Укажите значения ВКЛ и ВЫКЛ');
      if (g('fOn') === g('fOff')) return err('Значения ВКЛ и ВЫКЛ должны отличаться');
      card.onValue = g('fOn'); card.offValue = g('fOff');
    }
    if (t === 'level') {
      const min = Number(g('fMin').replace(',', '.')), max = Number(g('fMax').replace(',', '.'));
      if (g('fMin').trim() === '' || g('fMax').trim() === '' || !isFinite(min) || !isFinite(max)) return err('Минимум и максимум должны быть числами');
      if (min >= max) return err('Минимум должен быть меньше максимума');
      card.min = min; card.max = max; card.prefix = g('fPrefix'); card.suffix = g('fSuffix');
    }
    if (t === 'button') card.value = g('fVal');
    addCard(card);
    closeModal();
  };
}

/* ---------- таблица и журнал ---------- */
function renderTopics() {
  const rows = Object.entries(topics).sort((a, b) => a[0].localeCompare(b[0]));
  $('topics').innerHTML = rows.length
    ? rows.map(([t, v]) => `<tr><td>${esc(t)}</td><td>${esc(v.payload)}</td><td>${fmtTime(v.ts)}</td><td>${esc(v.from)}</td></tr>`).join('')
    : '<tr><td colspan="4" class="muted">сообщений пока нет</td></tr>';
}

function addLog(e) {
  const box = $('log');
  const stick = box.scrollTop + box.clientHeight >= box.scrollHeight - 20;
  const d = document.createElement('div');
  if (e.kind === 'sys') {
    d.className = 'sys';
    d.textContent = `${fmtTime(e.ts)}  ${e.text}`;
  } else {
    d.innerHTML = `${fmtTime(e.ts)}  <span class="t">${esc(e.topic)}</span> = ${esc(e.payload)}  <span class="sys">(${esc(e.from)}${e.retain ? ', retain' : ''})</span>`;
  }
  box.appendChild(d);
  while (box.childNodes.length > 300) box.removeChild(box.firstChild);
  if (stick) box.scrollTop = box.scrollHeight;
}

/* ---------- поток событий ---------- */
function connect() {
  if (es) es.close();
  es = new EventSource('/api/events?token=' + encodeURIComponent(token));
  es.onmessage = (m) => {
    const { type, data } = JSON.parse(m.data);
    if (type === 'init') {
      topics = data.topics;
      $('log').innerHTML = '';
      data.log.forEach(addLog);
      renderEsp(data.esp); renderDeck(); renderTopics();
    } else if (type === 'topic') {
      topics[data.topic] = data;
      renderDeck(); renderTopics();
    } else if (type === 'log') addLog(data);
    else if (type === 'esp') renderEsp(data);
  };
  es.onerror = async () => {
    // сервер мог перезапуститься и забыть вход
    try {
      const r = await fetch('/api/settings', { headers: { 'X-Token': token || '' } });
      if (r.status === 401) toAuth();
    } catch (e) { /* сервер недоступен, EventSource переподключится сам */ }
  };
}

/* ---------- старт ---------- */
loadInfo();
setAuthMode('login');
if (token) startApp(); else toAuth();
